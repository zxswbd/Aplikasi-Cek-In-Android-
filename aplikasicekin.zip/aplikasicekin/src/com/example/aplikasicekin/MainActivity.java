package com.example.aplikasicekin;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQUEST_CODE_PILIH_APLIKASI = 1;

    private ListView listView;
    private TextView emptyView;
    private Button addButton;
    private CekInAdapter adapter;
    private ArrayList<CekInItem> cekInList;
    private DatabaseHelper dbHelper;

    private String selectedPackageName = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        listView = (ListView) findViewById(R.id.listViewCekIn);
        emptyView = (TextView) findViewById(R.id.emptyView);
        addButton = (Button) findViewById(R.id.addButton);
        
        loadDataFromDatabase();

        adapter = new CekInAdapter(this, cekInList);
        listView.setAdapter(adapter);
        
        updateEmptyViewVisibility();
        
        registerForContextMenu(listView);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddDialog();
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                CekInItem item = cekInList.get(position);
                handleStreak(item);
                
                try {
                    Intent intent = getPackageManager().getLaunchIntentForPackage(item.getPackageName());
                    if (intent != null) {
                        startActivity(intent);
                    } else {
                        Toast.makeText(MainActivity.this, "Aplikasi tidak ditemukan", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Gagal membuka aplikasi", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // --- FUNGSI BARU UNTUK MENAMPILKAN MENU ---
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    // --- FUNGSI BARU UNTUK MENANGANI KLIK MENU ---
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.action_hint) {
            showHintDialog();
            return true;
        } else if (itemId == R.id.action_credits) {
            Toast.makeText(this, "Aplikasi ini dibuat oleh zxswbd", Toast.LENGTH_LONG).show();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        if (v.getId() == R.id.listViewCekIn) {
            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.menu_edit_delete, menu);
        }
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        final CekInItem selectedItem = cekInList.get(info.position);

        int itemId = item.getItemId();
        if (itemId == R.id.menu_edit) {
            showEditDialog(selectedItem);
            return true;
        } else if (itemId == R.id.menu_delete) {
            new AlertDialog.Builder(this)
                .setTitle("Hapus Cek In")
                .setMessage("Yakin ingin menghapus '" + selectedItem.getJudul() + "'?")
                .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        cancelAlarms(selectedItem);
                        dbHelper.deleteCekIn(selectedItem.getId());
                        loadDataFromDatabase();
                        adapter.notifyDataSetChanged();
                        Toast.makeText(MainActivity.this, "Item dihapus", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Tidak", null)
                .show();
            return true;
        } else {
            return super.onContextItemSelected(item);
        }
    }

    private void handleStreak(CekInItem item) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        String todayDateStr = sdf.format(new Date());

        if (todayDateStr.equals(item.getLastCheckinDate())) {
            Toast.makeText(this, "Cek In untuk '" + item.getJudul() + "' sudah dilakukan hari ini.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            Date lastDate = sdf.parse(item.getLastCheckinDate());
            Calendar cal = Calendar.getInstance();
            cal.setTime(lastDate);
            cal.add(Calendar.DATE, 1);
            String nextDayDateStr = sdf.format(cal.getTime());

            if (todayDateStr.equals(nextDayDateStr)) {
                item.setStreak(item.getStreak() + 1);
                Toast.makeText(this, "Streak berlanjut! " + item.getStreak() + " hari!", Toast.LENGTH_SHORT).show();
            } else {
                item.setStreak(1);
                Toast.makeText(this, "Streak dimulai!", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            item.setStreak(1);
            Toast.makeText(this, "Streak dimulai!", Toast.LENGTH_SHORT).show();
        }

        item.setLastCheckinDate(todayDateStr);
        dbHelper.updateCekInStreak(item);
        adapter.notifyDataSetChanged();
    }
    
    private void showTimePickerDialog(final Button timeButton, final int timeIndex, final String[] times) {
        Calendar mcurrentTime = Calendar.getInstance();
        int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
        int minute = mcurrentTime.get(Calendar.MINUTE);
        TimePickerDialog mTimePicker;
        mTimePicker = new TimePickerDialog(MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                String time = String.format(Locale.getDefault(), "%02d:%02d", selectedHour, selectedMinute);
                times[timeIndex - 1] = time;
                timeButton.setText("Waktu " + timeIndex + ": " + time);
            }
        }, hour, minute, true);
        mTimePicker.setTitle("Pilih Waktu ke-" + timeIndex);
        mTimePicker.show();
    }

    private void showAddDialog() {
        showItemDialog(null);
    }

    private void showEditDialog(CekInItem item) {
        showItemDialog(item);
    }

    private void showItemDialog(final CekInItem item) {
        final boolean isEditMode = item != null;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(isEditMode ? "Edit Cek In" : "Tambah Cek In Baru");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 50, 50, 50);

        final EditText inputJudul = new EditText(this);
        inputJudul.setHint("Judul (Contoh: Belajar Java)");
        layout.addView(inputJudul);

        final EditText inputReward = new EditText(this);
        inputReward.setHint("Reward (Contoh: Nonton YouTube)");
        layout.addView(inputReward);

        Button btnPilihApp = new Button(this);
        btnPilihApp.setText("Pilih Aplikasi Reward");
        layout.addView(btnPilihApp);

        final Button btnPilihWaktu1 = new Button(this);
        layout.addView(btnPilihWaktu1);
        final Button btnPilihWaktu2 = new Button(this);
        layout.addView(btnPilihWaktu2);
        final Button btnPilihWaktu3 = new Button(this);
        layout.addView(btnPilihWaktu3);
        
        final String[] times = new String[3];
        
        if (isEditMode) {
            inputJudul.setText(item.getJudul());
            inputReward.setText(item.getReward());
            selectedPackageName = item.getPackageName();
            times[0] = item.getReminderTime1();
            times[1] = item.getReminderTime2();
            times[2] = item.getReminderTime3();
            btnPilihWaktu1.setText("Waktu 1: " + times[0]);
            btnPilihWaktu2.setText("Waktu 2: " + times[1]);
            btnPilihWaktu3.setText("Waktu 3: " + times[2]);
        } else {
            selectedPackageName = null;
            btnPilihWaktu1.setText("Pilih Waktu Pengingat 1");
            btnPilihWaktu2.setText("Pilih Waktu Pengingat 2");
            btnPilihWaktu3.setText("Pilih Waktu Pengingat 3");
        }

        btnPilihApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, PilihAplikasiActivity.class);
                startActivityForResult(intent, REQUEST_CODE_PILIH_APLIKASI);
            }
        });

        btnPilihWaktu1.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showTimePickerDialog(btnPilihWaktu1, 1, times); } });
        btnPilihWaktu2.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showTimePickerDialog(btnPilihWaktu2, 2, times); } });
        btnPilihWaktu3.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showTimePickerDialog(btnPilihWaktu3, 3, times); } });

        builder.setView(layout);
        
        builder.setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String judul = inputJudul.getText().toString();
                String reward = inputReward.getText().toString();
                if (judul.isEmpty() || reward.isEmpty() || selectedPackageName == null || times[0] == null || times[1] == null || times[2] == null) {
                    Toast.makeText(MainActivity.this, "Semua kolom harus diisi", Toast.LENGTH_SHORT).show();
                    return;
                }
                
                if (isEditMode) {
                    dbHelper.updateCekInDetails(item.getId(), judul, reward, selectedPackageName, times[0], times[1], times[2]);
                    cancelAlarms(item);
                    scheduleAlarms(item.getId(), judul, selectedPackageName, times);
                } else {
                    long newId = dbHelper.addCekIn(judul, reward, selectedPackageName, times[0], times[1], times[2]);
                    scheduleAlarms((int) newId, judul, selectedPackageName, times);
                }
                loadDataFromDatabase();
                adapter.notifyDataSetChanged();
            }
        });
        
        builder.setNegativeButton("Batal", null);
        builder.create().show();
    }
    
    private void showHintDialog() {
        new AlertDialog.Builder(this)
            .setTitle("Petunjuk Penggunaan")
            .setMessage(
                "1. Tekan tombol '+' untuk membuat Cek In baru.\n\n" +
                "2. Isi semua data yang diperlukan (Judul, Reward, Aplikasi, dan 3 Waktu Pengingat).\n\n" +
                "3. Klik pada item di daftar untuk menjalankan Cek In dan menambah Poin Streak.\n\n" +
                "4. Tekan lama pada item untuk memunculkan pilihan Edit atau Hapus.\n\n" +
                "5. Streak akan bertambah jika Cek In dilakukan setiap hari, dan akan kembali ke 0 jika terlewat."
            )
            .setPositiveButton("Mengerti", null)
            .show();
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_PILIH_APLIKASI && resultCode == RESULT_OK) {
            if (data != null) {
                selectedPackageName = data.getStringExtra("packageName");
                String appName = data.getStringExtra("appName");
                Toast.makeText(this, "Aplikasi dipilih: " + appName, Toast.LENGTH_SHORT).show();
            }
        }
    }
    
    @Override
    protected void onResume(){
        super.onResume();
        loadDataFromDatabase();
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }

    private void loadDataFromDatabase() {
        if(cekInList == null) cekInList = new ArrayList<>();
        cekInList.clear();
        Cursor cursor = dbHelper.getAllCekIn();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
                String judul = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_JUDUL));
                String reward = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_REWARD));
                String packageName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PACKAGE_NAME));
                int streak = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_STREAK));
                String lastCheckin = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_LAST_CHECKIN));
                String time1 = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_REMINDER_TIME_1));
                String time2 = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_REMINDER_TIME_2));
                String time3 = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_REMINDER_TIME_3));
                
                cekInList.add(new CekInItem(id, judul, reward, packageName, streak, lastCheckin, time1, time2, time3));
            } while (cursor.moveToNext());
        }
        cursor.close();
        updateEmptyViewVisibility();
    }
    
    private void scheduleAlarms(int itemId, String judul, String packageName, String[] times) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        for (int i = 0; i < times.length; i++) {
            String[] timeParts = times[i].split(":");
            int hour = Integer.parseInt(timeParts[0]);
            int minute = Integer.parseInt(timeParts[1]);

            Intent intent = new Intent(this, AlarmReceiver.class);
            intent.putExtra("judul", judul);
            intent.putExtra("packageName", packageName);
            
            int notificationId = itemId * 10 + i;
            intent.putExtra("notificationId", notificationId);

            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, notificationId, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(System.currentTimeMillis());
            calendar.set(Calendar.HOUR_OF_DAY, hour);
            calendar.set(Calendar.MINUTE, minute);
            calendar.set(Calendar.SECOND, 0);

            if (calendar.getTimeInMillis() <= System.currentTimeMillis()) {
                calendar.add(Calendar.DAY_OF_YEAR, 1);
            }
            
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent);
        }
        Toast.makeText(this, "3 Pengingat harian diaktifkan untuk " + judul, Toast.LENGTH_LONG).show();
    }

    private void cancelAlarms(CekInItem item) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        for (int i = 0; i < 3; i++) {
            Intent intent = new Intent(this, AlarmReceiver.class);
            int notificationId = item.getId() * 10 + i;
            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, notificationId, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            alarmManager.cancel(pendingIntent);
        }
    }
    
    private void updateEmptyViewVisibility(){
        if (adapter != null) adapter.notifyDataSetChanged();
        
        if (cekInList.isEmpty()) {
            emptyView.setVisibility(View.VISIBLE);
            listView.setVisibility(View.GONE);
        } else {
            emptyView.setVisibility(View.GONE);
            listView.setVisibility(View.VISIBLE);
        }
    }
}