package com.example.aplikasicekin;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.ArrayList;

public class CekInAdapter extends ArrayAdapter<CekInItem> {

    public CekInAdapter(Context context, ArrayList<CekInItem> items) {
        super(context, 0, items);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        CekInItem item = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_cekin, parent, false);
        }

        TextView judulText = convertView.findViewById(R.id.judulText);
        TextView rewardText = convertView.findViewById(R.id.rewardText);
        TextView streakText = convertView.findViewById(R.id.streakText);
        TextView reminderText = convertView.findViewById(R.id.reminderText);

        judulText.setText(item.getJudul());
        rewardText.setText("Reward: " + item.getReward());
        streakText.setText("🔥 Streak: " + item.getStreak());
        
        // Gabungkan 3 waktu menjadi satu string
        String reminderTimes = "⏰ Pengingat: " + item.getReminderTime1() + ", " + item.getReminderTime2() + ", " + item.getReminderTime3();
        reminderText.setText(reminderTimes);

        return convertView;
    }
}