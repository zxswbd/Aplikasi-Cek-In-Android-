package com.example.aplikasicekin;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class PilihAplikasiActivity extends Activity {

    private ListView listView;
    private SearchView searchView;
    private AplikasiAdapter adapter;
    private ArrayList<AplikasiInfo> appList;
    private PackageManager packageManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pilih_aplikasi);

        packageManager = getPackageManager();
        listView = findViewById(R.id.listViewAplikasi);
        searchView = findViewById(R.id.searchView);
        appList = new ArrayList<>();
        
        new LoadAppsTask().execute();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                AplikasiInfo selectedApp = (AplikasiInfo) parent.getItemAtPosition(position);
                Intent resultIntent = new Intent();
                resultIntent.putExtra("packageName", selectedApp.packageName.toString());
                resultIntent.putExtra("appName", selectedApp.label.toString());
                setResult(Activity.RESULT_OK, resultIntent);
                finish();
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if(adapter != null){
                   adapter.getFilter().filter(newText);
                }
                return true;
            }
        });
    }

    private class LoadAppsTask extends AsyncTask<Void, Void, ArrayList<AplikasiInfo>> {
        private ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(PilihAplikasiActivity.this);
            progressDialog.setMessage("Memuat aplikasi...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }

        @Override
        protected ArrayList<AplikasiInfo> doInBackground(Void... params) {
            ArrayList<AplikasiInfo> loadedApps = new ArrayList<>();
            List<ApplicationInfo> packages = packageManager.getInstalledApplications(PackageManager.GET_META_DATA);

            for (ApplicationInfo packageInfo : packages) {
                if (packageManager.getLaunchIntentForPackage(packageInfo.packageName) != null) {
                    AplikasiInfo newApp = new AplikasiInfo();
                    newApp.label = packageInfo.loadLabel(packageManager);
                    newApp.packageName = packageInfo.packageName;
                    newApp.icon = packageInfo.loadIcon(packageManager);
                    loadedApps.add(newApp);
                }
            }

            Collections.sort(loadedApps, new Comparator<AplikasiInfo>() {
                @Override
                public int compare(AplikasiInfo o1, AplikasiInfo o2) {
                    return o1.label.toString().compareToIgnoreCase(o2.label.toString());
                }
            });

            return loadedApps;
        }

        @Override
        protected void onPostExecute(ArrayList<AplikasiInfo> result) {
            super.onPostExecute(result);
            if (progressDialog.isShowing()) {
                progressDialog.dismiss();
            }
            appList = result;
            adapter = new AplikasiAdapter(PilihAplikasiActivity.this, appList);
            listView.setAdapter(adapter);
        }
    }
}