package com.example.aplikasicekin;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "CekIn.db";
    private static final int DATABASE_VERSION = 4;
    private static final String TABLE_NAME = "cekin_items";

    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_JUDUL = "judul";
    public static final String COLUMN_REWARD = "reward";
    public static final String COLUMN_PACKAGE_NAME = "package_name";
    public static final String COLUMN_STREAK = "streak";
    public static final String COLUMN_LAST_CHECKIN = "last_checkin";
    
    public static final String COLUMN_REMINDER_TIME_1 = "reminder_time_1";
    public static final String COLUMN_REMINDER_TIME_2 = "reminder_time_2";
    public static final String COLUMN_REMINDER_TIME_3 = "reminder_time_3";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_JUDUL + " TEXT, " +
                COLUMN_REWARD + " TEXT, " +
                COLUMN_PACKAGE_NAME + " TEXT, " +
                COLUMN_STREAK + " INTEGER DEFAULT 0, " +
                COLUMN_LAST_CHECKIN + " TEXT DEFAULT '1970-01-01', " +
                COLUMN_REMINDER_TIME_1 + " TEXT, " +
                COLUMN_REMINDER_TIME_2 + " TEXT, " +
                COLUMN_REMINDER_TIME_3 + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + COLUMN_STREAK + " INTEGER DEFAULT 0");
            db.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + COLUMN_LAST_CHECKIN + " TEXT DEFAULT '1970-01-01'");
        }
        if (oldVersion < 4) {
            db.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + COLUMN_REMINDER_TIME_1 + " TEXT");
            db.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + COLUMN_REMINDER_TIME_2 + " TEXT");
            db.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + COLUMN_REMINDER_TIME_3 + " TEXT");
        }
    }

    public long addCekIn(String judul, String reward, String packageName, String time1, String time2, String time3) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_JUDUL, judul);
        cv.put(COLUMN_REWARD, reward);
        cv.put(COLUMN_PACKAGE_NAME, packageName);
        cv.put(COLUMN_STREAK, 0);
        cv.put(COLUMN_LAST_CHECKIN, "1970-01-01");
        cv.put(COLUMN_REMINDER_TIME_1, time1);
        cv.put(COLUMN_REMINDER_TIME_2, time2);
        cv.put(COLUMN_REMINDER_TIME_3, time3);
        return db.insert(TABLE_NAME, null, cv);
    }

    public Cursor getAllCekIn() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }

    public void updateCekInStreak(CekInItem item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_STREAK, item.getStreak());
        cv.put(COLUMN_LAST_CHECKIN, item.getLastCheckinDate());
        db.update(TABLE_NAME, cv, COLUMN_ID + "=?", new String[]{String.valueOf(item.getId())});
    }
    
    // FUNGSI BARU UNTUK EDIT DATA
    public void updateCekInDetails(int id, String judul, String reward, String packageName, String time1, String time2, String time3) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_JUDUL, judul);
        cv.put(COLUMN_REWARD, reward);
        cv.put(COLUMN_PACKAGE_NAME, packageName);
        cv.put(COLUMN_REMINDER_TIME_1, time1);
        cv.put(COLUMN_REMINDER_TIME_2, time2);
        cv.put(COLUMN_REMINDER_TIME_3, time3);
        db.update(TABLE_NAME, cv, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }

    public void deleteCekIn(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }
}