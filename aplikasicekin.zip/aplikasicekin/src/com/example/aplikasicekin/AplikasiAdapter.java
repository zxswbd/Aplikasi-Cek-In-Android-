package com.example.aplikasicekin;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class AplikasiAdapter extends ArrayAdapter<AplikasiInfo> {
    
    private ArrayList<AplikasiInfo> originalList;
    private ArrayList<AplikasiInfo> filteredList;
    private AppFilter filter;

    public AplikasiAdapter(Context context, ArrayList<AplikasiInfo> appList) {
        super(context, 0, appList);
        this.originalList = new ArrayList<>(appList);
        this.filteredList = appList;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_aplikasi, parent, false);
        }

        AplikasiInfo currentApp = getItem(position);

        ImageView appIcon = convertView.findViewById(R.id.appIcon);
        TextView appName = convertView.findViewById(R.id.appName);

        if (currentApp != null) {
            appIcon.setImageDrawable(currentApp.icon);
            appName.setText(currentApp.label);
        }

        return convertView;
    }
    
    @Override
    public Filter getFilter() {
        if (filter == null) {
            filter = new AppFilter();
        }
        return filter;
    }

    private class AppFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();
            ArrayList<AplikasiInfo> filtered = new ArrayList<>();

            if (constraint == null || constraint.length() == 0) {
                filtered.addAll(originalList);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();
                for (AplikasiInfo item : originalList) {
                    if (item.label.toString().toLowerCase().contains(filterPattern)) {
                        filtered.add(item);
                    }
                }
            }

            results.values = filtered;
            results.count = filtered.size();
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            filteredList.clear();
            filteredList.addAll((ArrayList<AplikasiInfo>) results.values);
            notifyDataSetChanged();
        }
    }
}