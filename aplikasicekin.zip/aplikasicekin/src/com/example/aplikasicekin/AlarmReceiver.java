package com.example.aplikasicekin;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {

    public static final String NOTIFICATION_CHANNEL_ID = "10001";

    @Override
    public void onReceive(Context context, Intent intent) {
        String judul = intent.getStringExtra("judul");
        String packageName = intent.getStringExtra("packageName");
        int notificationId = intent.getIntExtra("notificationId", 0);

        PendingIntent contentIntent;
        PackageManager pm = context.getPackageManager();
        
        Intent targetAppIntent = pm.getLaunchIntentForPackage(packageName);

        if (targetAppIntent != null) {
            contentIntent = PendingIntent.getActivity(context, notificationId, targetAppIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        } else {
            Intent mainIntent = new Intent(context, MainActivity.class);
            contentIntent = PendingIntent.getActivity(context, notificationId, mainIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        }

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder builder;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    NOTIFICATION_CHANNEL_ID,
                    "CekIn Reminder",
                    NotificationManager.IMPORTANCE_HIGH 
            );
            channel.enableVibration(true);
            // BARIS BARU: Memaksa notifikasi untuk muncul di layar kunci
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            notificationManager.createNotificationChannel(channel);
            builder = new Notification.Builder(context, NOTIFICATION_CHANNEL_ID);
        } else {
            builder = new Notification.Builder(context);
        }

        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Waktunya Cek In!")
                .setContentText("Jangan lupa untuk: " + judul)
                .setContentIntent(contentIntent)
                .setPriority(Notification.PRIORITY_HIGH)
                .setCategory(Notification.CATEGORY_ALARM)
                .setFullScreenIntent(contentIntent, true)
                .setAutoCancel(true);
        
        notificationManager.notify(notificationId, builder.build());
    }
}