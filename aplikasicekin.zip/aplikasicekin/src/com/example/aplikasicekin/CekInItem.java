package com.example.aplikasicekin;

public class CekInItem {
    private int id;
    private String judul;
    private String reward;
    private String packageName;
    private int streak;
    private String lastCheckinDate;
    private String reminderTime1;
    private String reminderTime2;
    private String reminderTime3;

    public CekInItem(int id, String judul, String reward, String packageName, int streak, String lastCheckinDate, String reminderTime1, String reminderTime2, String reminderTime3) {
        this.id = id;
        this.judul = judul;
        this.reward = reward;
        this.packageName = packageName;
        this.streak = streak;
        this.lastCheckinDate = lastCheckinDate;
        this.reminderTime1 = reminderTime1;
        this.reminderTime2 = reminderTime2;
        this.reminderTime3 = reminderTime3;
    }

    // Getter methods
    public int getId() { return id; }
    public String getJudul() { return judul; }
    public String getReward() { return reward; }
    public String getPackageName() { return packageName; }
    public int getStreak() { return streak; }
    public String getLastCheckinDate() { return lastCheckinDate; }
    public String getReminderTime1() { return reminderTime1; }
    public String getReminderTime2() { return reminderTime2; }
    public String getReminderTime3() { return reminderTime3; }

    // Setter methods
    public void setStreak(int streak) { this.streak = streak; }
    public void setLastCheckinDate(String date) { this.lastCheckinDate = date; }
}