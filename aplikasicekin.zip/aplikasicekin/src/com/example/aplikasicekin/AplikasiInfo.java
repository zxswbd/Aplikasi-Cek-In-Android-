package com.example.aplikasicekin;

import android.graphics.drawable.Drawable;

public class AplikasiInfo {
    CharSequence label;
    CharSequence packageName;
    Drawable icon;
}